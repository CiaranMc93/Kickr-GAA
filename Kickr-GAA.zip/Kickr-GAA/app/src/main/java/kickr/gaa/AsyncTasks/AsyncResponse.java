package kickr.gaa.AsyncTasks;

import kickr.gaa.CustomObjects.MatchObj;

import java.util.ArrayList;

/**
 * Created by cmcmanus on 11/29/2017.
 */

public interface AsyncResponse {
    void processFinish(ArrayList<MatchObj> matchList);

    void processDBQueries(ArrayList<MatchObj> resultData);
}
